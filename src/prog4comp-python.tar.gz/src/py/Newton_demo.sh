python Newton_demo.py "x*(1-x)*(x-2)" "2*x - 3*x**2 - 2 + 4*x" -0.6 -1 3
