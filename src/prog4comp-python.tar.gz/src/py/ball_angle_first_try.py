x = 10             # Horizontal position
y = 10             # Vertical position

angle = atan(y/x)        

print (angle/pi)*180
