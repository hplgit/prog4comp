#!/bin/sh
python growth1.py <<EOF
100
0.1
0.5
40
EOF

python growth1.py <<EOF
100
0.1
0.05
400
EOF

python growth1.py <<EOF
100
0.1
2
10
EOF

