function result = f(x)
    result = @(x) x^2 - 9;
end
