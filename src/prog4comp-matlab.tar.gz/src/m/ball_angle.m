x = 10;   % Horizontal position
y = 10;   % Vertical position

angle = atan(y/x);
(angle/pi)*180     % Computes and prints to screen
